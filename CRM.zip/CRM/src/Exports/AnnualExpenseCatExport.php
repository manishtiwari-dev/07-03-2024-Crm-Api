<?php

namespace Modules\CRM\Exports;


use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Events\BeforeSheet;
use Maatwebsite\Excel\Events\BeforeExport;
use Modules\CRM\Models\ACCTransactionHead;
use Modules\CRM\Models\AccTransactions;
use Modules\CRM\Models\AccCategories;
use Carbon\Carbon;
use Modules\CRM\Models\AccInvoices;
use App\Models\Order;
use Modules\CRM\Models\CRMCustomer;

use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Maatwebsite\Excel\Concerns\WithTitle; 
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Sheet;


class AnnualExpenseCatExport implements FromCollection, WithTitle, WithStyles
{
    private $mon;
    private $year;
    protected $rowIds = []; 
    protected $row = []; 

    public function __construct(int $year, int $mon)
    {
        $this->mon = $mon;
        $this->year  = $year;
    }

    public function collection()
    {

         
        $year = $this->year;
        $mon = $this->mon;

         
		$result = collect([]);
       $accCategorys = AccCategories::where('dr_cr' , 'dr')->where('status' , 1)->get(); 

        $Tjan = $Tfeb = $Tmar = $Tapr = $Tmay = $Tjun = $Tjul = $Taug = $Tsep = $Toct = $Tnov = $Tdec = $TAccAmt = 0;
        $row = 2;
       foreach($accCategorys as $key => $accCategory){
       	
       		if($key == 0){
                $result->add([
                    "Particulars",   
                    "Jan ".$year, 
                    "Feb ".$year, 
                    "Mar ".$year, 
                    "Apr ".$year, 
                    "May ".$year, 
                    "Jun ".$year, 
                    "Jul ".$year, 
                    "Aug ".$year, 
                    "Sept".$year, 
                    "Oct ".$year, 
                    "Nov ".$year, 
                    "Dec ".$year,
                    "Total",
                 ]);
            }

            $jan = $feb = $mar = $apr = $may = $jun = $jul = $aug = $sep = $oct = $nov = $dec = $TAcc = 0;

            for($i=01; $i<=12; $i++){
                $acctxns = AccTransactions::where('txn_category' , $accCategory->id)->whereYear('txn_date' , $year)->whereMonth('txn_date' , $i)->get();

                foreach ($acctxns as $key => $acctxn) {
                    $TAccAmt+=$acctxn->amount;
                    $TAcc+=$acctxn->amount;

                    if($i == '01'){
                        $jan+=$acctxn->amount;
                    }else if($i == '02'){
                        $feb+=$acctxn->amount;
                    }else if($i == '03'){
                        $mar+=$acctxn->amount;
                    }else if($i == '04'){
                        $apr+=$acctxn->amount;
                    }else if($i == '05'){
                        $may+=$acctxn->amount;
                    }else if($i == '06'){
                        $jun+=$acctxn->amount;
                    }else if($i == '07'){
                        $jul+=$acctxn->amount;
                    }else if($i == '08'){
                        $aug+=$acctxn->amount;
                    }else if($i == '09'){
                        $sep+=$acctxn->amount;
                    }else if($i == '10'){
                        $oct+=$acctxn->amount;
                    }else if($i == '11'){
                        $nov+=$acctxn->amount;
                    }else if($i == '12'){
                        $dec+=$acctxn->amount;
                    }

                }
            }

            $result->add([
                    $accCategory->name, 
                    $jan,
                    $feb,
                    $mar,
                    $apr,
                    $may,
                    $jun,
                    $jul,
                    $aug,
                    $sep,
                    $oct,
                    $nov,
                    $dec, 
                    $TAcc,
                     
                 ]);

            $Tjan += $jan;
            $Tfeb += $feb;
            $Tmar += $mar;
            $Tapr += $apr;
            $Tmay += $may;
            $Tjun += $jun;
            $Tjul += $jul;
            $Taug += $aug;
            $Tsep += $sep;
            $Toct += $oct;
            $Tnov += $nov;
            $Tdec += $dec;

        $row++;

            if($key == 0){
                $this->rowIds[] = 1;
            }
            
            
       } 
       $this->row[] = $row;

       
       $result->add([
                    "Total Expense", 
                    $Tjan,
                    $Tfeb,
                    $Tmar,
                    $Tapr,
                    $Tmay,
                    $Tjun,
                    $Tjul,
                    $Taug,
                    $Tsep,
                    $Toct,
                    $Tnov,
                    $Tdec,
                    $TAccAmt,
                     
                 ]);
 

        return $result;

    }

  

    public function title(): string
    { 
        return "Expense";
    }


    public function styles(Worksheet $sheet)
    {
        $sheet->getStyle('A:A')->getFont()->setBold(true);
         
         $styles = [];

        foreach ($this->rowIds as $rowId) {
            $styles[$rowId] =[
                    'font' => [
                        'bold' => true,
                        'color' => ['rgb' => 'F74510'], // Setting the font color to red
                    ],
                    'fill' => [
                        'fillType' => 'solid',
                        'startColor' => ['rgb' => '85C1E9'], // Setting the cell background color
                    ],
                ];
        }

        foreach ($this->row as $rowId) {
            $styles[$rowId] =[
                    'font' => [
                        'bold' => true,
                        'color' => ['rgb' => '0f0f0f'], // Setting the font color to red
                    ],
                    'fill' => [
                        'fillType' => 'solid',
                        'startColor' => ['rgb' => 'dadce0'], // Setting the cell background color
                    ],
                ];
        }

        return $styles;
    }

    

     


    
}
