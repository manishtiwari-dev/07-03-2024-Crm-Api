<?php

namespace Modules\CRM\Exports;

use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;

class ReportYearExport implements WithMultipleSheets
{
    use Exportable;

    protected $reportData;

    public function __construct(array $reportData)
    {
        $this->reportData = $reportData; 
    }


    /**
     * @return array
     */
    public function sheets(): array
    {
        $sheets = [];
        $year = $this->reportData['year'];
        $mon = $this->reportData['year'];

        $sheets[] = new AnnualPLAccExport($year, $mon);
        $sheets[] = new AnnualBankAccExport($year, $mon);
        $sheets[] = new AnnualincomeCatExport($year, $mon);
        $sheets[] = new AnnualExpenseCatExport($year, $mon);



        for ($month = 12; $month >= 01; $month--) {
            $sheets[] = new AnnualReportsExport($year, $month);
        }

        return $sheets;
    }
}
