<?php

namespace Modules\CRM\Exports;

use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use Maatwebsite\Excel\Events\BeforeSheet;
use Maatwebsite\Excel\Events\BeforeExport;
use Modules\CRM\Models\ACCTransactionHead;
use Modules\CRM\Models\AccTransactions;
use Modules\CRM\Models\ACCTransactionRemittance;
use Carbon\Carbon;
use Modules\CRM\Models\AccInvoices;
use App\Models\Order;
use Modules\CRM\Models\CRMCustomer;

use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Maatwebsite\Excel\Concerns\WithTitle; 
use Maatwebsite\Excel\Sheet;


class ReportsExport implements FromCollection, ShouldAutoSize, WithStyles, WithTitle
{
    use Exportable;

    protected $reportData;
    protected $rowIds = []; 
    protected $row = [];

    public function __construct(array $reportData)
    {
        $this->reportData = $reportData; 
          
    }

    public function collection()
    {

 
         
        $month = $this->reportData['month'];
        $year = $this->reportData['year'];

         
        $transactionHeads = ACCTransactionHead::where('status' , 1)->get(); 


        $result = collect([]);
        $rowIds = 1;
        foreach($transactionHeads as $key => $transactionHead){
             $this->rowIds[] = $rowIds;
            $rowIds++;
            $accCount = AccTransactions::where('txn_head' , $transactionHead->id)->whereMonth('txn_date', $month)->whereYear('txn_date', $year)->count();
               ;  
            if($key == 0){ 
                $method = "Payment Method - Bank Account";
                $no = "Invoice No";
                $send = "Send";
                $receive = "Received";
                $charge = "Charge";
                $exchange = "Exchange Rate";
                $bankCharge = "Bank Charge";
            }else{
                $method = "";
                $no = "";
                $send = "";
                $receive = "";
                $charge = "";
                $exchange = "";
                $bankCharge = "";
            }
            $result->add([
                    "",  
                    $transactionHead->head_title,
                    "",
                    $method,
                    $no,
                    $send,
                    $receive,
                    $charge,
                    $exchange,
                    $bankCharge,
                 ]);

            

            if($transactionHead->transactions){ 

                $amt=0;
                $transactiondf = AccTransactions::where('txn_head' , $transactionHead->id)->whereMonth('txn_date', $month)->whereYear('txn_date', $year)->get();
                $row = 0;
                foreach($transactiondf as $transaction){
                    $rowIds++;
                    $amt+=$transaction->amount ?? 0;
                    
                    if(!empty($transaction->source_id)){
                        if($transaction->source == 1){
                            $customer = CRMCustomer::where('customer_id',$transaction->source_id)->first();
                            $number = $customer->first_name;
                        }else if($transaction->source == 2){
                            $order = Order::where('order_id',$transaction->source_id)->first();
                             $number = $order->order_number;
                        }else{
                            $acc_no = AccInvoices::where('id',$transaction->source_id)->first();
                            $number = $acc_no->invoice_number;
                        }
                    }else{
                        $number = '';
                    }


                    $result->add([ 
                        $transaction->txn_date ?? '',
                        $transaction->txn_title ?? '',
                        $transaction->amount ?? '',
                        $transaction->remitance->paymentmethods->method_name ?? '',
                        $number,
                        $transaction->remitance->sent_amt ?? '',
                        $transaction->remitance->received_amt ?? '',
                        $transaction->remitance->charges ?? '',
                        $transaction->remitance->exchange_rate ?? '',
                        $transaction->remitance->bank_charge ?? '', 

                     ]);
                }

                    $this->row[] = $rowIds;
                
                $rowIds++;
                $result->add([
                    "",  
                    "Total ".$transactionHead->head_title,
                    $amt,
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                 ]);
                
                $rowIds++;
                $result->add([
                    "",  
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                 ]);


            }


            // if($key == 0){
            //     $this->rowIds[] = 1;
            // }
            $this->rowIds[] = $rowIds;
        

        
        }

 


        return $result;


    }

 
 

    public function styles(Worksheet $sheet)
    {
 

        $styles = [];

        foreach ($this->rowIds as $rowId) {
            $styles[$rowId] =[
                    'font' => [
                        'bold' => true,
                        'color' => ['rgb' => 'F74510'], // Setting the font color to red
                    ],
                    'fill' => [
                        'fillType' => 'solid',
                        'startColor' => ['rgb' => '85C1E9'], // Setting the cell background color
                    ],
                ];
        }

        foreach ($this->row as $rowId) {
            $styles[$rowId] =[
                    'font' => [
                        'bold' => true,
                        'color' => ['rgb' => '0f0f0f'], // Setting the font color to red
                    ],
                    'fill' => [
                        'fillType' => 'solid',
                        'startColor' => ['rgb' => 'dadce0'], // Setting the cell background color
                    ],
                ];
        }

        return $styles;


    }

    public function title(): string
    {

        $month = $this->reportData['month'];
        $year = $this->reportData['year'];

        $monthName = Carbon::create(null, $month, 1)->format('M');

        return $monthName.' '.$year;
    }


    // public function registerEvents(): array
    // {
        // return [
        //     AfterSheet::class => function (AfterSheet $event) {
        //         $sheet = $event->sheet();

        //         foreach ($this->rowIds as $rowId) {
        //             $startColumn = "A";
        //             $lastColumn = "C";
        //             $highestRow = $rowId;

        //             $mergeStartCell = $startColumn . $highestRow;
        //             $mergeEndCell = $lastColumn . $highestRow;

        //             $sheet->getDelegate()->mergeCells($mergeStartCell . ':' . $mergeEndCell);

        //             // Retrieve the content from the merged range and set it back to the top-left cell
        //             $mergedContent = $sheet->getDelegate()->rangeToArray($mergeStartCell . ':' . $mergeEndCell);
        //             $sheet->getDelegate()->setCellValue($mergeStartCell, $mergedContent[0][0]);
        //         }
        //     },
        // ];
    // }


     


    
}
