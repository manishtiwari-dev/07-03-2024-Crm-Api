<?php

namespace Modules\CRM\Exports;

use Modules\CRM\Models\AccTransactions;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Events\AfterSheet;
use Maatwebsite\Excel\Events\BeforeExport;
use Carbon\Carbon;


class TransactionExport implements FromCollection, WithHeadings, ShouldAutoSize
{
    use Exportable;

    protected $filters;
    public function __construct(array $filters)
    {
        $this->filters = $filters; 
    }

    public function collection()
    {

        $acc_transaction = config('dbtable.acc_transactions'); 
        $accounts =config('dbtable.acc_accounts');  
        $application_status =config('dbtable.rec_application_status'); 



        // Fetching All Job Applications

        // $jobApplications = AccTransactions::selectRaw('DATE(created_at) as date,id, txn_type,reference,dr_cr,amount');
            
        $jobApplications = AccTransactions::select( 
            ''.$acc_transaction.'.txn_date',   
            ''.$acc_transaction.'.txn_title',
            ''.$acc_transaction.'.amount',
            ''.$acc_transaction.'.dr_cr',  
            ''.$accounts.'.account_title', 
        )->leftJoin(''.$accounts.'', ''.$accounts.'.id', '=', ''.$acc_transaction.'.account_id')->orderBy($acc_transaction.'.id', 'desc');

        
        if ($this->filters['txnhead'] != 'all' && $this->filters['txnhead'] != '') {
            $jobApplications = $jobApplications->where(''.$acc_transaction.'.txn_head', $this->filters['txnhead']);
        }

        // Filter  By Location
        if ($this->filters['txncategory'] != 'all' && $this->filters['txncategory'] != '') {
            $jobApplications = $jobApplications->where(''.$acc_transaction.'.txn_category', $this->filters['txncategory']);
        }

        // Filter  By Location
        if ($this->filters['accounts'] != 'all' && $this->filters['accounts'] != '') {
            $jobApplications = $jobApplications->where(''.$acc_transaction.'.account_id', $this->filters['accounts']);
        }
        // Filter  By StartDate of job
        if ($this->filters['startDate'] != 'all' && $this->filters['startDate'] != null && $this->filters['startDate'] != '' && $this->filters['startDate'] != 0) {
            $startDate = $this->filters['startDate'];
            $jobApplications = $jobApplications->whereDate(''.$acc_transaction.'.txn_date', '>=', "$startDate");
        }
        // Filter  By EndDate of job
        if ($this->filters['endDate'] != 'all' && $this->filters['endDate'] != null && $this->filters['endDate'] != '' && $this->filters['endDate'] != 0) {
            $endDate = $this->filters['endDate'];

            $jobApplications = $jobApplications->whereDate(''.$acc_transaction.'.txn_date', '<=', "$endDate");
        } 
        $jobApplications = $jobApplications->get();
    
        return $jobApplications;


    }

 

    public function headings(): array
    {
        return ['Date', 'Title', 'Amount','Type' ,'Accounts'];
    }

    
}
