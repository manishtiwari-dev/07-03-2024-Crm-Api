<?php

namespace Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
use Modules\CRM\Models\CRMLeadSettingAgent;
use Modules\CRM\Models\Super\LandingCrmAgent;

class CRMAgentController extends Controller
{

    public $page = 'agent';
    public $landingpage = 'Clients';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : 10;
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;
        if ($userType == 'subscriber') {
            $data_query = CRMLeadSettingAgent::query();
        } else {
            $data_query = LandingCrmAgent::query();
        }

        if (!empty($search))
            $data_query = $data_query->where("agent_alias", "LIKE", "%{$search}%");

        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('agent_id', 'ASC');
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
        $user_count = $data_query->count();

        $data_list = $data_query->skip($skip)->take($perPage)->get();

        $data_list = $data_list->map(function ($data) {
            $data->status = ($data->status == 1) ? "active" : "deactive";
            return $data;
        });

        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int)$user_count / (int)$perPage),
            'per_page' => $perPage
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        //validation check 
        $rules = [
            'agent_alias' => 'required|string',
            'user_id' => 'required',
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, '', $validator->messages());

        $data = $request->except(['api_token']);

        if ($userType == 'subscriber') {
            $crmagentname = CRMLeadSettingAgent::where('agent_name', $data)->first();

            if (!empty($crmagentname)) {
                return ApiHelper::JSON_RESPONSE(false, '', 'AGENT_NAME_ALREADY_EXIST');
            } else {
                $prdopval = CRMLeadSettingAgent::create($data);
            }
        } else {

            $crmagentname = LandingCrmAgent::where('agent_name', $data)->first();

            if (!empty($crmagentname)) {
                return ApiHelper::JSON_RESPONSE(false, '', 'AGENT_NAME_ALREADY_EXIST');
            } else {
                $prdopval = LandingCrmAgent::create($data);
            }
        }




        return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_AGENT_ADD');


        // if ($prdopval) {
        //     return ApiHelper::JSON_RESPONSE(true, $prdopval, 'SUCCESS_AGENT_ADD');
        // } else {
        //     return ApiHelper::JSON_RESPONSE(false,'', 'ERROR_AGENT_ADD');
        // }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $response = CRMLeadSettingAgent::find($request->agent_id);
        return ApiHelper::JSON_RESPONSE(true, $response, '');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        //validation check 
        $rules = [
            'agent_alias' => 'required|string',
            'status' => 'required',
            'user_id' => 'required',
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, '', $validator->messages());

        $data = $request->except(['api_token', 'agent_id']);

        if ($userType == 'subscriber') {
            $prdopval = CRMLeadSettingAgent::where('agent_id', $request->agent_id)
                ->update($data);
        } else {
            $prdopval = LandingCrmAgent::where('agent_id', $request->agent_id)
                ->update($data);
        }


        if ($prdopval) {
            return ApiHelper::JSON_RESPONSE(true, $prdopval, 'SUCCESS_AGENT_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_AGENT_UPDATE');
        }
    }
}
