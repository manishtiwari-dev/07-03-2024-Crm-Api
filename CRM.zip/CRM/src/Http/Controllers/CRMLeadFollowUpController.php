<?php

namespace Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
use Modules\CRM\Models\CRMLeadFollowUp;
use Modules\CRM\Models\CRMLeadFollowUpHistory;
use Modules\CRM\Models\CRMLeadFollowupNote;
use Modules\CRM\Models\CRMLeadSettingGroup;
use Modules\CRM\Models\CRMLeadSettingSource;
use Modules\CRM\Models\CRMLeadSettingAgent;
use Modules\CRM\Models\CRMLeadSocialLink;
use Modules\CRM\Models\CRMLeadSettingStatus;
use Modules\CRM\Models\CRMLead;
use Modules\CRM\Models\CRMLeadSettingTag;
use DateTime;
use Modules\CRM\Models\Super\LandingCrmLead;
use Modules\CRM\Models\Super\LandingCrmAgent;
use Modules\CRM\Models\Super\LandingCrmIndustry;
use Modules\CRM\Models\Super\LandingCrmLeadStatus;
use Modules\CRM\Models\Super\LandingCrmTags;
use Modules\CRM\Models\Super\LandingCrmLeadToTag;
use Modules\CRM\Models\Super\LandingCrmNotes;
use Modules\CRM\Models\Super\LandingCrmLeadFollowUpHistory;
use Modules\CRM\Models\Super\LandingCrmLeadSocialLink;
use Modules\CRM\Models\Super\LandingCrmLeadSource;
use Modules\CRM\Models\Super\LandingCrmLeadContact;
use Modules\CRM\Models\Super\LandingCrmLeadFollowUp;
use Carbon\Carbon;


class CRMLeadFollowUpController extends Controller
{

    public $page = 'lead_followup';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index(Request $request)
    {
        // // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);


        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');



        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;
        if ($userType == 'subscriber') {
            $data_query = CRMLeadFollowUp::with('crmLeadStatus', 'crm_lead', 'enquiry', 'quotation', 'order')->orderBy('followup_id', 'DESC');
            $crmagentlist = CRMLeadSettingAgent::where('status', 1)->orderBy('agent_id', 'DESC')->get();
            $crmLeadStatus = CRMLeadSettingStatus::with('crmLeadFollowUp')->where('status', 1)->get();
            $sourcelist = CRMLeadSettingSource::where('status', 1)->orderBy('source_id', 'DESC')->get();
            $crmtags = CRMLeadSettingTag::where('status', 1)->get();
        } else {
            $data_query = LandingCrmLeadFollowUp::with('crmLeadStatus', 'crm_lead', 'enquiry',)->orderBy('followup_id', 'DESC');
            $crmagentlist = LandingCrmAgent::orderBy('agent_id', 'DESC')->get();
            $crmtags = LandingCrmTags::where('status', 1)->get();
        }



        if (!empty($search)) {
            $data_query =  $data_query->orWhereHas('crm_lead', function ($query) use ($search) {
                $query->where('crm_lead.contact_email', 'Like', '%' . $search . '%');
            });
        }
        if (!empty($search)) {
            $data_query =  $data_query->orWhereHas('crm_lead', function ($query) use ($search) {
                $query->where('crm_lead.contact_name', 'Like', '%' . $search . '%');
            });
        }

        if ($request->has('source_name')) {
            if ($request->source_name != NULL) {
                $data_query = $data_query->where("source_id",  $request->source_name);
            }
        }
        if ($request->has('followup')) {
            if ($request->followup != NULL) {
                $data_query = $data_query->where("followup_status",  $request->followup);
            }
        }



        $agent_id = $request->agent_id;

        if (empty($request->search)) {
            if ($request->has('agent_id')) {
                if (!empty($request->agent_id)) {
                    $data_query =  $data_query->orWhereHas('crm_lead', function ($query) use ($agent_id) {
                        $query->where('crm_lead.agent_id', $agent_id);
                    });
                }
            }

            if ($request->has('tagSelect')) {
                if (!empty($request->tagSelect)) {
                    $tag_select = $request->tagSelect;
                    $data_query =  $data_query->orWhereHas('crm_lead.crmLeadToTag', function ($query) use ($tag_select) {
                        $query->whereIn('crm_lead_to_tags.tags_id', $tag_select);
                    });
                }
            }
        }





        if (empty($request->search)) {
            /* Add Start Date Filter  */
            if ($request->has('start_date')) {
                if ($request->start_date != NULL) {
                    $myDateTime = DateTime::createFromFormat('Y-m-d', $request->start_date);
                    $start_date = $myDateTime->format('Y-m-d');
                    $data_query = $data_query->whereDate('created_at', '>=', $start_date);
                }
            }

            /* Add End Date Filter  */
            if ($request->has('end_date')) {
                if ($request->end_date != NULL) {
                    $myDateTime = DateTime::createFromFormat('Y-m-d', $request->end_date);
                    $end_date = $myDateTime->format('Y-m-d');
                    $data_query = $data_query->whereDate('created_at', '<=', $end_date);
                }
            }
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
        $user_count = $data_query->count();
        $data_list = $data_query->skip($skip)->take($perPage)->get();

        $res = [
            'lead_list' => $data_list,
            // 'leadstatus' => $leadstatus,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int)$user_count / (int)$perPage),
            'per_page' => $perPage,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
            'crmagentlist' => $crmagentlist,
            'crmtags' => $crmtags,
            'sourcelist' => $sourcelist,
            'crmLeadStatus' => $crmLeadStatus,
            'search' => $search,
            'source_name' => $request->source_name,
            'followup' => $request->followup,
            'tags' => $request->tagSelect,
            'crm_agent' => $request->agent_id
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        // if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
        //     return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        //validation check 
        $rules = [
            'lead_id' => 'required',
            'followup_status' => 'required',
            'followup_note' => 'required',
            'followup_date' => 'required',
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, '', $validator->messages());

        $data = $request->except(['api_token']);

        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $prdopval = CRMLeadFollowUp::create($data);
        } else {
            $prdopval = LandingCrmLeadFollowUp::create($data);
        }

        if ($prdopval) {
            return ApiHelper::JSON_RESPONSE(true, $prdopval, 'SUCCESS_FOLLOW_UP_ADD');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_FOLLOW_UP_ADD');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $response = CRMLeadFollowUp::find($request->followup_id);
        } else {
            $response = LandingCrmLeadFollowUp::find($request->followup_id);
        }

        return ApiHelper::JSON_RESPONSE(true, $response, '');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        // if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
        //     return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        //validation check 
        $rules = [
            'lead_id' => 'required',
            'followup_status' => 'required',
            'followup_note' => 'required',
            'followup_date' => 'required',
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, '', $validator->messages());

        $data = $request->except(['api_token', 'followup_id']);
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $prdopval = CRMLeadFollowUp::where('followup_id', $request->followup_id)
                ->update($data);
        } else {
            $prdopval = LandingCrmLeadFollowUp::where('followup_id', $request->followup_id)
                ->update($data);
        }



        if ($prdopval) {
            return ApiHelper::JSON_RESPONSE(true, $prdopval, 'SUCCESS_FOLLOW_UP_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_FOLLOW_UP_UPDATE');
        }
    }



    public function followUpStore(Request $request)
    {
        $api_token = $request->api_token;
        $user_id = ApiHelper::get_user_id_from_token($api_token);

        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $crm_lead_followUp = CRMLeadFollowUp::updateOrCreate(
                [
                    'lead_id' => $request->lead_id,
                    // 'followup_id' => $request->followup_id,
                    'source' => $request->source,
                    'source_id' => $request->source_id,
                ],
                [
                    'lead_id' => $request->lead_id,
                    "source" => $request->source,
                    "source_id" => $request->source_id,
                    'followup_status' => $request->followup_status,
                    'last_followup' => Carbon::createFromFormat('d/m/Y',  $request->followupdate)->format('Y-m-d'),
                    'next_followup' => Carbon::createFromFormat('d/m/Y',  $request->next_followup)->format('Y-m-d'),
                    'followup_nos' => $request->followup_nos,
                    'followup_tag' => $request->followup_tag,
                    'created_by' => $user_id,
                ]
            );


            $crm_leadHistory = CRMLeadFollowUpHistory::create([

                'followup_id' => $crm_lead_followUp->followup_id,
                'followup_at' => Carbon::createFromFormat('d/m/Y',  $request->followupdate)->format('Y-m-d'),
                'followup_status' => $request->followup_status,
                'followup_note' => $request->followup_note,
            ]);
        } else {
            $crm_lead_followUp = LandingCrmLeadFollowUp::updateOrCreate(
                [
                    'lead_id' => $request->lead_id,
                    'source' => $request->source,
                    'source_id' => $request->source_id,
                ],
                [
                    'lead_id' => $request->lead_id,
                    "source" => $request->source,
                    "source_id" => $request->source_id,
                    'followup_status' => $request->followup_status,
                    'last_followup' => Carbon::createFromFormat('d/m/Y',  $request->followupdate)->format('Y-m-d'),
                    'next_followup' =>  Carbon::createFromFormat('d/m/Y',  $request->next_followup)->format('Y-m-d'),
                    'followup_nos' => $request->followup_nos,
                    'followup_tag' => $request->followup_tag,
                    'created_by' => $user_id,
                ]
            );

            $crm_leadHistory = LandingCrmLeadFollowUpHistory::create([

                'followup_id' => $crm_lead_followUp->followup_id,
                'followup_at' => Carbon::createFromFormat('d/m/Y',  $request->followupdate)->format('Y-m-d'),
                'followup_status' => $request->followup_status,
                'followup_note' => $request->followup_note,
            ]);
        }




        return ApiHelper::JSON_RESPONSE(true, $crm_lead_followUp, 'SUCCESS_FOLLOWUP_STORE');
    }

    public function GetFollowup(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {

            $crmLeadHistoryList = CRMLeadFollowUpHistory::with('crmLeadStatus')->where('followup_id', $request->followup_id)->orderBy('id', 'DESC')->get();
        } else {
            $crmLeadHistoryList = LandingCrmLeadFollowUpHistory::with('crmLeadStatus')->where('followup_id', $request->followup_id)->orderBy('id', 'DESC')->get();
        }


        return ApiHelper::JSON_RESPONSE(true, $crmLeadHistoryList, '');
    }

    public function followUphistory(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $crmfollowup = CRMLeadFollowUp::where('source', $request->type)->where('source_id', $request->enquiry_id)->first();

            if ($crmfollowup) {
                $crmLeadHistoryList = CRMLeadFollowUpHistory::with('crmLeadStatus')->where('followup_id', $crmfollowup->followup_id)->orderBy('id', 'DESC')->get();
            } else {
                $crmLeadHistoryList = '';
            }
        } else {
            $crmfollowup = LandingCrmLeadFollowUp::where('source', $request->type)->where('source_id', $request->enquiry_id)->first();

            if ($crmfollowup) {
                $crmLeadHistoryList = LandingCrmLeadFollowUpHistory::with('crmLeadStatus')->where('followup_id', $crmfollowup->followup_id)->orderBy('id', 'DESC')->get();
            } else {
                $crmLeadHistoryList = '';
            }
        }


        return ApiHelper::JSON_RESPONSE(true, $crmLeadHistoryList, '');
    }

    public function NoteStore(Request $request)
    {

        $api_token = $request->api_token;
        $user_id = ApiHelper::get_user_id_from_token($api_token);



        $crm_lead_note = CRMLeadFollowupNote::create([
            'lead_id' => $request->lead_id,
            'note_details' => $request->note_details,
            'note_visibility' => $request->note_visibility,
            'created_by' => $user_id,
        ]);


        return ApiHelper::JSON_RESPONSE(true, $crm_lead_note, 'SUCCESS_NOTE_STORE');
    }

    public function LeadTagUpdate(Request $request)
    {

        $Taglist = $request->tag_id;

        if (!empty($Taglist)) {
            // $lead_tag = CRMLead::where('lead_id', $request->lead_id)->update(
            //     [                
            //         'tags' => implode(',',$value),
            //     ]
            // );

            $postTag = CRMLead::find($request->lead_id);
            $postTag->crmLeadToTag()->detach();


            $LeadToTag = [];
            foreach ($Taglist as $key => $tag_id) {
                $LeadToTag[$key]['lead_id'] = $postTag->lead_id;
                $LeadToTag[$key]['tags_id'] = $tag_id;
            }
            $lead_tag = $postTag->crmLeadToTag()->attach($LeadToTag);
        } else {
            $lead_tag = CRMLead::where('lead_id', $request->lead_id)->update(
                [
                    'tags' => null,
                ]
            );
        }



        if ($lead_tag)
            return ApiHelper::JSON_RESPONSE(true, $lead_tag, 'SUCCESS_LEAD_TAG_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_LEAD_TAG_UPDATE');
    }
}
