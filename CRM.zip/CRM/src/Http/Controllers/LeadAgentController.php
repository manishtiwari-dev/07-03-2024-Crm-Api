<?php

namespace Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
use Modules\CRM\Models\CRMLeadSettingAgent;
use Modules\CRM\Models\CRMLeadSettingTag;
use Modules\CRM\Models\Super\LandingCrmAgent;
use Modules\CRM\Models\Super\LandingCrmTags;
use Modules\HRM\Models\Department;
use Modules\HRM\Models\Staff;
use App\Models\UserHasRole;
use App\Models\User;
use Modules\Department\Models\Role;

class LeadAgentController extends Controller
{

    public $page = 'lead_setting';
    public $landingpage = 'Clients';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */



    public function deptUser(Request $request)
    {
        // $department_list = Staff::where('department_id', $request->dept_id)->get();

        $useRoleList = UserHasRole::where('roles_id' , $request->dept_id)->get();

        foreach($useRoleList as $useRole){
            $userList[] = User::where('id' , $useRole->users_id)->get();
        }



        return ApiHelper::JSON_RESPONSE(true, $userList, '');
    }

    public function agentStore(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        if ($userType == 'subscriber') {
            $crmagent = CRMLeadSettingAgent::where('agent_name', $request->agent_name)->first();

             $max_sortOrder =  CRMLeadSettingAgent::max('sort_order');
            $sort_order = $max_sortOrder + 1;


            if (!empty($crmagent)) {
                return ApiHelper::JSON_RESPONSE(false, '', 'AGENT_NAME_ALREADY_EXIST');
            } else {
                $crmagent =  CRMLeadSettingAgent::create([
                    'user_id' => $request->user_id,
                    'agent_name' => $request->agent_name,
                    'communication_id' => $request->communication,
                    'sort_order' => $sort_order
                ]);
            }
        } else {
            $crmagent = LandingCrmAgent::where('agent_name', $request->agent_name)->first();

            if (!empty($crmagent)) {
                return ApiHelper::JSON_RESPONSE(false, '', 'AGENT_NAME_ALREADY_EXIST');
            } else {
                $crmagent =  LandingCrmAgent::create([
                    //     'user_id' => $request->user_id,
                    'agent_name' => $request->agent_name,
                    'communication_id' => $request->communication
                ]);
            }
        }



        return ApiHelper::JSON_RESPONSE(true, $crmagent, 'SUCCESS_AGENT_STORE');
    }



    public function agentEdit(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        if ($userType == 'subscriber') {
            $agent = CRMLeadSettingAgent::find($request->agent_id);



            $dept_list = Role::all();

            // $userList = Staff::where('department_id', $staff->department_id)->get();

             $userId = UserHasRole::where('users_id' , $agent->user_id)->first();

            $staff = User::where('id' , $agent->user_id)->first();

             $useRoleList = UserHasRole::where('roles_id' , $userId->roles_id)->get();

// return ApiHelper::JSON_RESPONSE(true, $request->agent_id, '');
            foreach($useRoleList as $useRole){
                $userList[] = User::where('id' , $useRole->users_id)->get();
            }

        } else {
            $agent = LandingCrmAgent::find($request->agent_id);
            $staff = Staff::where('user_id', $agent->user_id)->first();
            $dept_list = Department::all();

            $userList = Staff::where('department_id', $staff->department_id)->get();
        }



        $response = [
            'agent' => $agent,
            'staff' => $staff,
            'dept_list' => $dept_list,
            'userList' => $userList,
            'userId'=>$userId
        ];

        return ApiHelper::JSON_RESPONSE(true, $response, '');
    }


    public function agentUpdate(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        //validation check 
        $rules = [
            'agent_name' => 'required|string',

        ];
        $validator = Validator::make($request->all(), $rules);


        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, '', $validator->messages());

        if ($userType == 'subscriber') {

            $crmagent = CRMLeadSettingAgent::where('agent_id', $request->agent_id)->update(
                [
                    'user_id' => $request->user_id,
                    'agent_name' => $request->agent_name,
                    'communication_id' => $request->communication

                ]
            );
        } else {

            $crmagent = LandingCrmAgent::where('agent_id', $request->agent_id)->update(
                [
                    'user_id' => $request->user_id,
                    'agent_name' => $request->agent_name,
                    'communication_id' => $request->communication

                ]
            );
        }






        if ($crmagent) {
            return ApiHelper::JSON_RESPONSE(true, $crmagent, 'SUCCESS_AGENT_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_AGENT_UPDATE');
        }
    }

    public function changeStatus(Request $request)
    {

        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $agent =  CRMLeadSettingAgent::where('agent_id', $request->agent_id)->first();
            $agent->status = $request->status;
            $agent->update();
        } else {
            $agent =  LandingCrmAgent::where('agent_id', $request->agent_id)->first();
            $agent->status = $request->status;
            $agent->update();
        }


        return ApiHelper::JSON_RESPONSE(true, $agent, 'SUCCESS_STATUS_UPDATE');
    }

    public function tagStore(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $crmleadtag = CRMLeadSettingTag::where('tags_name', $request->tags_name)->first();

            $max_sortOrder =  CRMLeadSettingTag::max('sort_order');
            $sort_order = $max_sortOrder + 1;

            if (!empty($crmleadtag)) {
                return ApiHelper::JSON_RESPONSE(false, '', 'TAGS_NAME_ALREADY_EXIST');
            } else {
                $crmtags =  CRMLeadSettingTag::create([
                    'tags_name' => $request->tags_name,
                    'tags_color' => $request->tags_color,
                    'sort_order' => $sort_order,
                ]);
            }
        } else {
            $crmleadtag = LandingCrmTags::where('tags_name', $request->tags_name)->first();

            if (!empty($crmleadtag)) {
                return ApiHelper::JSON_RESPONSE(false, '', 'TAGS_NAME_ALREADY_EXIST');
            } else {
                $crmtags =  LandingCrmTags::create([
                    'tags_name' => $request->tags_name,
                    'tags_color' => $request->tags_color,
                ]);
            }
        }




        return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_TAG_STORE');

        // return ApiHelper::JSON_RESPONSE(true, $crmtags, 'SUCCESS_TAG_STORE');
    }

    public function tagsEdit(Request $request)
    {

        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $tags = CRMLeadSettingTag::find($request->tags_id);
        } else {
            $tags = LandingCrmTags::find($request->tags_id);
        }


        $response = [
            'tags' => $tags
        ];

        return ApiHelper::JSON_RESPONSE(true, $response, '');
    }

    public function tagsUpdate(Request $request)
    {

        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $crmtags = CRMLeadSettingTag::where('tags_id', $request->tag_id)->update(
                [
                    'tags_name' => $request->tags_name,
                    'tags_color' => $request->tags_color,
                ]
            );
        } else {
            $crmtags = LandingCrmTags::where('tags_id', $request->tag_id)->update(
                [
                    'tags_name' => $request->tags_name,
                    'tags_color' => $request->tags_color,
                ]
            );
        }




        if ($crmtags) {
            return ApiHelper::JSON_RESPONSE(true, $crmtags, 'SUCCESS_TAGS_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_TAGS_UPDATE');
        }
    }


    public function changeTagStatus(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $agent =  CRMLeadSettingTag::where('tags_id', $request->tag_id)->first();
            $agent->status = $request->status;
            $agent->update();
        } else {
            $agent =  LandingCrmTags::where('tags_id', $request->tag_id)->first();
            $agent->status = $request->status;
            $agent->update();
        }


        return ApiHelper::JSON_RESPONSE(true, $agent, 'SUCCESS_STATUS_UPDATE');
    }

    public function tagsShortOrder(Request $request){
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');



        if ($userType == 'subscriber') {

            $crmTags = CRMLeadSettingTag::where('tags_id', $request->status_id)->first();

            if (!empty($crmTags)) {
                $crmTags->sort_order = $request->sort_order;
                $crmTags->update();

                return ApiHelper::JSON_RESPONSE(true, $crmTags, 'SUCCESS_SORT_ORDER_UPDATE');
            }
        } 
    }
}
