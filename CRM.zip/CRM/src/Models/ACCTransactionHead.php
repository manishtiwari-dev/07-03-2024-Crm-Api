<?php
namespace Modules\CRM\Models;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model; 
use Illuminate\Support\Str;
use Modules\CRM\Models\CRMCustomer;

class ACCTransactionHead extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',
        
    ];
    public function getTable()
    {
        return config('dbtable.acc_transaction_head');
    }

    public function transactions()
    {

        return $this->hasMany(AccTransactions::class, 'txn_head', 'id');
    }

 
 
    
 
}
