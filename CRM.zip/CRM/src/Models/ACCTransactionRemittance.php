<?php
namespace Modules\CRM\Models;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model; 
use App\Models\PaymentMethods;

class ACCTransactionRemittance extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',
        
    ];
    public function getTable()
    {
        return config('dbtable.acc_transaction_remittance');
    }

    
    public function paymentmethods(){
        
         return $this->hasOne(PaymentMethods::class , 'payment_method_id' , 'payment_method_id');
    }
    
 
}
