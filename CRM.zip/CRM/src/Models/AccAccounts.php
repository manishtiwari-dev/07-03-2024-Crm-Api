<?php
namespace Modules\CRM\Models;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model; 

class AccAccounts extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',
        
    ];
    public function getTable()
    {
        return config('dbtable.acc_accounts');
    }


    public function transaction(){

    	 return $this->belongsTo(AccTransactions::class , 'account_id' , 'id');

    }
    
 
}
