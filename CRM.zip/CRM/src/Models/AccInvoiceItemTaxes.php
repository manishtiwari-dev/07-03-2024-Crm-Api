<?php
namespace Modules\CRM\Models;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model; 
use Illuminate\Support\Str;
use Modules\CRM\Models\CRMCustomer;

class AccInvoiceItemTaxes extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',
        
    ];
    public function getTable()
    {
        return config('dbtable.acc_invoice_item_taxes');
    }
 

 
    
 
}
