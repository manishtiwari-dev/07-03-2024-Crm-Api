<?php
namespace Modules\CRM\Models;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model; 
use Illuminate\Support\Str;
use Modules\CRM\Models\CRMCustomer;

class AccInvoices extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',
        
    ];
    public function getTable()
    {
        return config('dbtable.acc_invoices');
    }

    public function customer(){
    	return $this->belongsTo(CRMCustomer::class, 'customer_id', 'customer_id');
    }

    public function crm_invoice_item()
    {
        return $this->hasMany(AccInvoicesItem::class, 'invoice_id', 'id');
    }


    public function acc_transaction()
    {
        return $this->hasMany(AccTransactions::class, 'source_id', 'id');
    }

 
    
 
}
