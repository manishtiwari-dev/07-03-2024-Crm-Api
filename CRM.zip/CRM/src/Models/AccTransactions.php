<?php
namespace Modules\CRM\Models;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model; 
use Modules\CRM\Models\AccAccounts;

class AccTransactions extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',
        
    ];
    public function getTable()
    {
        return config('dbtable.acc_transactions');
    }
    
    public function Accounts(){
    	
    	 return $this->belongsTo(AccAccounts::class , 'account_id' , 'id');
    }

    public function remitance(){
        
         return $this->hasOne(ACCTransactionRemittance::class , 'txn_id' , 'id');
    }
 
}
