<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CRMAgentGroup extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',
        
    ];
    public function getTable()
    {
        return config('dbtable.crm_ticket_agent_groups');
    }

    public function crm_agent(){


        return $this->belongsTo(CRMLeadSettingAgent::class,'agent_id','agent_id');
    }
    
}
