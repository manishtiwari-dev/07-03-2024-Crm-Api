<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\CRM\Models\CRMCustomerAddress;
use Modules\CRM\Models\CRMCustomerContact;
use Modules\CRM\Models\CRMLead;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Modules\Ecommerce\Models\Order;
use Modules\CRM\Models\Enquiry;

class CRMCustomer extends Model
{
    use HasFactory;
    protected $primaryKey = 'customer_id';
    protected $guarded = [
        'customer_id',
        
    ];
    


    public function getTable()
    {
        return config('dbtable.crm_customer');
    }

    public function lead_data()
    {
      return $this->belongsTo(CRMLead::class,
        'lead_id','lead_id');


    }
    
    public function crm_customer_address()
    {
        return $this->hasMany(CRMCustomerAddress::class, 'customer_id', 'customer_id');
    }
    public function crm_customer_contact()
    {
        return $this->hasMany(CRMCustomerContact::class, 'customer_id', 'customer_id');
    }

     public function weborder()
    {
      return $this->belongsTo(Order::class, 'customer_id' , 'customer_id');

    }
      public function webenquiry()
    {
      return $this->belongsTo(Enquiry::class, 'customer_id' , 'customer_id');

    }

    public function crmquotation()
    {
      return $this->belongsTo(CRMQuotation::class, 'customer_id' , 'customer_id');

    }

    public function webenqcustomer()
    {
      return $this->hasMany(Enquiry::class, 'customer_id' , 'customer_id');

    }

    public function webquotecustomer()
    {
      return $this->hasMany(CRMQuotation::class, 'customer_id' , 'customer_id');

    }

    public function webordercustomer()
    {
      return $this->hasMany(Order::class, 'customer_id' , 'customer_id');

    }

    public function customer_address()
    {
        return $this->hasOne(CRMCustomerAddress::class, 'customer_id', 'customer_id');
    }
}
