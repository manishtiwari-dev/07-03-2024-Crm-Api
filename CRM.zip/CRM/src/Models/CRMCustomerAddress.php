<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Country;
class CRMCustomerAddress extends Model
{
    use HasFactory;
    protected $primaryKey = 'address_id';
    protected $guarded = ['address_id'];
    public function getTable()
    {
        return config('dbtable.crm_customer_address');
    }
    
    public function crm_quotation_country()
    {
        return $this->belongsTo(Country::class, 'countries_id', 'countries_id');
    }


}
