<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CRMLeadContact extends Model
{
    use HasFactory;
    protected $primaryKey = 'lead_contact_id';
    protected $guarded = ['lead_contact_id'];

    protected $fillable = [
        'lead_id',
        'contact_name',
        'company_name',
        'website',
        'street_address',
        'city',
        'state',
        'zipcode',
        'countries_id'
       
    ];
    public function getTable()
    {
        return config('dbtable.crm_lead_contact');
    }


     public function crmcustomer()
    {
      return $this->belongsTo(CRMCustomer::class, 'contact_email' , 'email');


    }
    
}
