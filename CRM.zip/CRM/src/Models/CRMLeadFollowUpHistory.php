<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CRMLeadFollowUpHistory extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $fillable = [
        'followup_id',
        'followup_at',
        'followup_status',
        'followup_note',
    ];
    public function getTable()
    {
        return config('dbtable.crm_lead_followup_history');
    }

    public $timestamps = false;


    public function crmLeadfollowup()
    {
      return $this->belongsTo(CRMLeadFollowUp::class, 'followup_id' , 'followup_id');

    }

    public function crmLeadStatus()
    {
      return $this->belongsTo(CRMLeadSettingStatus::class, 'followup_status' , 'status_id');

    }

    
}
