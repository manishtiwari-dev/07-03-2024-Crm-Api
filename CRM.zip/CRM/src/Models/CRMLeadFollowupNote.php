<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CRMLeadFollowupNote extends Model
{
    use HasFactory;
    protected $primaryKey = 'note_id';
    protected $fillable = [
        'lead_id', 
        'note_details',
        'note_visibility',
        'created_by',
    ];
    public function getTable()
    {
        return config('dbtable.crm_lead_followup_note');
    }


}
