<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CRMLeadSettingGroup extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $fillable = [
        'group_name',
        'sort_order',
        'status',
    ];
    public function getTable()
    {
        return config('dbtable.crm_lead_sett_group');
    }
    
}
