<?php
namespace Modules\CRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class CRMLeadSettingSource extends Model
{
    use HasFactory;
    protected $primaryKey = 'source_id';
    protected $fillable = [
        'source_name',
        'sort_order',
        'status',
    ];
    public function getTable()
    {
        return config('dbtable.crm_lead_sett_source');
    }
    
}
