<?php

namespace Modules\CRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class CRMLeadSettingStatus extends Model
{
    use HasFactory;
    protected $primaryKey = 'status_id';
    protected $fillable = [
        'status_name',
        'sort_order',
        'status_color',
        'status',
    ];
    public function getTable()
    {
        return config('dbtable.crm_lead_sett_status');
    }


    public function crmLeadFollowUp()
    {
        return $this->hasOne(CRMLeadFollowUpHistory::class, 'followup_status', 'status_id');
    }
}
