<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CRMLeadSettingTag extends Model
{
    use HasFactory;
    protected $primaryKey = 'tags_id';
    protected $guarded = [
        'tags_id',
        
    ];
    public function getTable()
    {
        return config('dbtable.crm_lead_sett_tags');
    }
    

    
}
