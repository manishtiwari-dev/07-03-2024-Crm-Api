<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CRMLeadSocialLink extends Model
{
    use HasFactory;
    protected $primaryKey = 'social_link_id';
    protected $fillable = [
        'lead_id',
        'social_type',
        'social_link',
        'status',
    ];
    public function getTable()
    {
        return config('dbtable.crm_lead_social_link');
    }
    
}
