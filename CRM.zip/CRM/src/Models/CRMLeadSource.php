<?php
namespace Modules\CRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class CRMLeadSource extends Model
{
    use HasFactory;
    protected $primaryKey = 'source_id';
    protected $fillable = [
        'source_name',
        'status',
    ];
    public function getTable()
    {
        return config('dbtable.crm_lead_source');
    }
    
}
