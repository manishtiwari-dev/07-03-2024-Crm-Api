<?php
namespace Modules\CRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class CRMLeadStatus extends Model
{
    use HasFactory;
    protected $primaryKey = 'status_id';
    protected $fillable = [
        'status_name',
        'sort_order',
        'status',
    ];
    public function getTable()
    {
        return config('dbtable.crm_lead_status');
    }
    
}
