<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\CRM\Models\CRMCustomerContact;
use Modules\CRM\Models\CRMCustomerAddress;


class CRMQuotation extends Model
{
    use HasFactory;
    protected $primaryKey = 'quotation_id';
    protected $guarded = ['quotation_id'];
    
    public function getTable()
    {
        return config('dbtable.crm_quotation');
    }

    public function crm_quotation_to_payment_term(){
        return $this->belongsToMany(CRMSettingPaymentTerms::class,config('dbtable.crm_quotation_to_payment_term'),'quotation_id','terms_id');
    }
    
    public function crm_quotation_item()
    {
        return $this->hasMany(CRMQuotationItem::class, 'quotation_id', 'quotation_id');
    }

    public function crm_quotation_customer()
    {
        return $this->belongsTo(CRMCustomer::class, 'customer_id', 'customer_id');
    }

    public function crm_quotation_contact()
    {
        return $this->belongsTo(CRMCustomerContact::class, 'billing_contact_id', 'contact_id');
    }

    public function crm_quotation_address()
    {
        return $this->belongsTo(CRMCustomerAddress::class, 'billing_address_id', 'address_id');
    }

    public static function quotationCount($id){

        $enqcount = CRMQuotation::where('customer_id' , $id)->count();

        return $enqcount;
    }


    public function followupstatus(){
        return $this->hasOne(CRMLeadFollowUp::class, 'source_id', 'quotation_id')->where('source' , 3);
    }

}
