<?php

namespace Modules\CRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\CRM\Models\CRMSettingTaxType;


class CRMSettingTax extends Model
{
    use HasFactory;
    protected $primaryKey = 'tax_id';
    protected $fillable = [
        'tax_type_id',
        'tax_percent',
        'status',
    ];
    public $timestamps = false;
    public function getTable()
    {
        return config('dbtable.crm_setting_tax_percent');
    }
    
    public function tax_typedetails(){
        return $this->hasOne(CRMSettingTaxType::class,'id','tax_type_id');
    }
}
