<?php

namespace Modules\CRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\CRM\Models\CRMSettingTaxGroup;
use Modules\CRM\Models\CRMSettingTaxType;


class CRMSettingTaxPercentage extends Model
{
    use HasFactory;
    protected $primaryKey = 'tax_id';
    protected $guarded = ['tax_id'];

    public function getTable()
    {
        return config('dbtable.crm_setting_tax_percent');
    }

    public $timestamps = false;

    public function tax_typedetails()
    {
        return $this->belongsTo(CRMSettingTaxType::class, 'tax_type_id', 'id');
    }

    public function taxGroupDetails()
    {
        return $this->belongsTo(CRMSettingTaxGroup::class, 'tax_group_id', 'tax_group_id');
    }
}
