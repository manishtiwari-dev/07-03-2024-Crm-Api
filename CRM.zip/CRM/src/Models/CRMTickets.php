<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;


class CRMTickets extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',
        
    ];
    public function getTable()
    {
        return config('dbtable.crm_tickets');
    }
    

     public function crm_agent(){


        return $this->belongsTo(CRMAgent::class,'agent_id','agent_id');
    }
    
     
    public function crm_agent_group(){


        return $this->belongsTo(CRMAgentGroup::class,'agent_id','agent_id');
    }
     

      public function user(){

        return $this->belongsTo(User::class,'user_id');
    }



      public function ticket_type(){

        return $this->belongsTo(CRMTicketsTypes::class,'type_id','id');
    }
   
}
