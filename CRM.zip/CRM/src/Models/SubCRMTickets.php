<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;
use App\Models\SubscriberBusiness;
use Modules\CRM\Models\SubCRMTicketsAgentGroup;
use Modules\CRM\Models\SubCRMTicketsTypes;
use Modules\CRM\Models\CRMCustomer;



class SubCRMTickets extends Model
{
    use HasFactory;

    
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',
        
    ];
  

    public function getTable()
    {
        return config('dbtable.crm_tickets');
    }


    
     
    public function crm_agent_group(){


        return $this->belongsTo(SubCRMTicketsAgentGroup::class,'agent_id','agent_id');
    }
     
   
    public function customer_list(){

        return $this->belongsTo(CRMCustomer::class,'customer_id','customer_id');
    }


      public function ticket_type(){

        return $this->belongsTo(SubCRMTicketsTypes::class,'type_id','id');
    }


 

}
