<?php
namespace Modules\CRM\Models\Super;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;
use App\Models\SubscriberBusiness;



class CRMTickets extends Model
{
    use HasFactory;

    
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',
        
    ];
  

    public function getTable()
    {
        return config('dbtable.sup_crm_tickets');
    }


    
     
    public function crm_agent_group(){


        return $this->belongsTo(CRMTicketsAgentGroup::class,'agent_id','agent_id');
    }
     

      public function user(){

        return $this->belongsTo(User::class,'user_id');
    }



      public function ticket_type(){

        return $this->belongsTo(CRMTicketsTypes::class,'type_id','id');
    }


    
    public function business_list(){

        return $this->belongsTo(SubscriberBusiness::class,'business_id','business_id');
    }
   

}
