<?php
namespace Modules\CRM\Models\Super;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\CRM\Models\CRMAgent;


class CRMTicketsAgentGroup extends Model
{
    use HasFactory;
  
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',
        
    ];
   
    public function getTable()
    {
        return config('dbtable.sup_crm_ticket_agent_groups');
    }

      public function crm_agent(){


        return $this->belongsTo(CRMAgent::class,'agent_id','agent_id');
    }
    
}
