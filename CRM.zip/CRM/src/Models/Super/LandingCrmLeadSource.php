<?php

namespace Modules\CRM\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class LandingCrmLeadSource extends Model
{
    use HasFactory;
    protected $primaryKey = 'source_id';
    protected $fillable = [
        'source_name',
        'status',
    ];
    public function getTable()
    {
        return config('dbtable.landing_crm_lead_source');
    }
}
