<?php

namespace Modules\CRM\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\CRM\Models\Super\LandingCrmLead;


class LandingCrmLeadToTag extends Model
{
    use HasFactory;

    protected $primaryKey = "lead_id";

    public $timestamps = false;

    protected $guarded = [

        'lead_id',
    ];


    public function getTable()
    {
        return config('dbtable.landing_crm_lead_to_tags');
    }

    public function crm_lead()
    {
        return $this->belongsTo(LandingCrmLead::class, 'lead_id', ' lead_id');
    }
}
